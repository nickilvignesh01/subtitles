import java.io.IOException;
import java.util.Map;

public class WordCounter {
    public static void main(String[] args) {
        String subtitleFilePath = "C://PSG TECH//SEM 2//JAVA LAB//PACKAGE//word//word//pack//endgame.srt";
        WordCounterProcessor processor = new WordCounterProcessor();

        try {
            Map<String, Integer> sortedWordCounts = processor.processSubtitleFile(subtitleFilePath);

            for (Map.Entry<String, Integer> entry : sortedWordCounts.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }

            processor.displayInUI(sortedWordCounts);

        } catch (IOException e) {
            System.err.println("Error reading the subtitle file: " + e.getMessage());
        }
    }
}
