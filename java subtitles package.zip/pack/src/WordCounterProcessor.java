import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class WordCounterProcessor {

    public Map<String, Integer> processSubtitleFile(String subtitleFilePath) throws IOException {
        Map<String, Integer> wordCounts = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(subtitleFilePath));

        String line;
        while ((line = reader.readLine()) != null) {
            String[] words = line.split("[\\s\\p{Punct}&&[^'{}]\\d]+");
            for (String word : words) {
                word = word.toLowerCase();
                wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
            }
        }
        reader.close();

        TreeMap<String, Integer> sortedWordCounts = new TreeMap<>((a, b) -> {
            int compare = wordCounts.get(b).compareTo(wordCounts.get(a));
            return compare != 0 ? compare : 1;
        });
        sortedWordCounts.putAll(wordCounts);

        return sortedWordCounts;
    }

    public void displayInUI(Map<String, Integer> wordCounts) {
        WordCounterUI ui = new WordCounterUI();
        ui.displayOutput(wordCounts);
    }
}
