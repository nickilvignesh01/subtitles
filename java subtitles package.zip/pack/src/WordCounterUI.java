import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class WordCounterUI {
    private JFrame frame;
    private JTextArea textArea;

    public WordCounterUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        frame = new JFrame();
        frame.setTitle("Movie Subtitles Word Counter"); // Set title
        frame.setSize(1600, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); // Center the frame on the screen

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(50, 700, 50, 700));
        panel.setBackground(new Color(240, 240, 240)); // Set background color
        panel.setOpaque(true); // Make the panel opaque

        JLabel titleLabel = new JLabel("Movie Subtitles Word Counter");
        titleLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 36));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titleLabel, BorderLayout.NORTH);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font(Font.MONOSPACED, Font.BOLD, 18));
        textArea.setBackground(Color.yellow);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setAlignmentX(Component.CENTER_ALIGNMENT); // Align text center

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBorder(BorderFactory.createEmptyBorder()); // Remove scroll pane border

        panel.add(Box.createRigidArea(new Dimension(100, 50)), BorderLayout.WEST);
        panel.add(scrollPane, BorderLayout.CENTER); // Add the scroll pane to the panel
        panel.add(Box.createRigidArea(new Dimension(100, 50)), BorderLayout.EAST);
        panel.add(Box.createRigidArea(new Dimension(100, 50)), BorderLayout.SOUTH);

        frame.add(panel);

        frame.setVisible(true);
    }

    public void displayOutput(Map<String, Integer> wordCounts) {

        StringBuilder output = new StringBuilder();
        for (Map.Entry<String, Integer> entry : wordCounts.entrySet()) {
            output.append(String.format("%-20s: %d%n", entry.getKey(), entry.getValue()));
        }

        textArea.setText(output.toString());
    }
}
